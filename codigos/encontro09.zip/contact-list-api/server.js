const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Initialize SQLite database
const db = new sqlite3.Database(':memory:', (err) => {
    if (err) {
        console.error(err.message);
    }
    console.log('Connected to the in-memory SQLite database.');
});

// Create contacts table
//phone TEXT NOT NULL UNIQUE CHECK(length(phone) = 14),
db.run(`CREATE TABLE contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,    
    phone TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE CHECK(length(email) <= 40)
)`);

// CRUD Operations

// Create contact
app.post('/contacts', (req, res) => {
    //console.log(req.body)
    const { name, phone, email } = req.body;
    //console.log("name: ", name, " phone: ", phone, " email: ", email)
    const sql = 'INSERT INTO contacts (name, phone, email) VALUES (?, ?, ?)';
    db.run(sql, [name, phone, email], function(err) {
        if (err) {
            return res.status(400).json({ error: err.message });
        }
        res.status(201).json({ id: this.lastID });
    });
});

// Read contacts
app.get('/', (req, res) => {
    let message = "Servidor ativo! Acesse localhost:port/contacts para usar a API";
    return res.status(200).send({ success: true, messageSid: message });
});

// Read contacts
app.get('/contacts', (req, res) => {
    const sql = 'SELECT * FROM contacts';
    db.all(sql, [], (err, rows) => {
        if (err) {
            return res.status(400).json({ error: err.message });
        }
        res.json(rows);
    });
});

// Update contact
app.put('/contacts/:id', (req, res) => {
    const { id } = req.params;
    const { name, phone, email } = req.body;
    const sql = 'UPDATE contacts SET name = ?, phone = ?, email = ? WHERE id = ?';
    db.run(sql, [name, phone, email, id], function(err) {
        if (err) {
            return res.status(400).json({ error: err.message });
        }
        res.status(200).json({ changes: this.changes });
    });
});

// Delete contact
app.delete('/contacts/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM contacts WHERE id = ?';
    db.run(sql, id, function(err) {
        if (err) {
            return res.status(400).json({ error: err.message });
        }
        res.status(204).send();
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
