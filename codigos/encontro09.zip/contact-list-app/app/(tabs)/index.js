import React, { useEffect, useState } from 'react';
import { View, Text, Button, FlatList, Alert } from 'react-native';
import axios from 'axios';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Tab = createBottomTabNavigator();

//const ContactList = () => {
export default function App() {
    const [contacts, setContacts] = useState([]);

    const fetchContacts = async () => {
        const response = await axios.get('http://localhost:3000/contacts');
        setContacts(response.data);
    };

    const handleDelete = async (id) => {
        try {
            const response = await axios.delete(`http://localhost:3000/contacts/${id}`);
            Alert.alert('Success', 'Contact deleted!');
            fetchContacts();
        } catch (error) {
            Alert.alert('Error', error.response.data.error);
        }
    };

    /* useEffect(() => {
        fetchContacts();
    }, []); */
    fetchContacts();

    if (contacts.length == 0)
       return (
        <Text>Não existem contatos cadastrados!</Text>
       )
    else {
      return (
        <>
        <h1>Contatos</h1>
        <FlatList
            data={contacts}
            keyExtractor={(item) => item.id.toString()}
            renderItem={({ item }) => (
                <View>
                    <Text>{item.name} - {item.phone} - {item.email}</Text>
                    <a href='#' onClick={() => handleDelete(item.id)}>Delete</a>
                    <Button title="Delete" onClickPress={() => handleDelete(item.id)} />
                </View>
            )}
        />
        </>
      );
    }
};

//export default ContactList;
