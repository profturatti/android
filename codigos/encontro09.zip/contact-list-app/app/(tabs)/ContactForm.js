import React, { useState } from 'react';
import { View, TextInput, Button, Alert } from 'react-native';
import axios from 'axios';

const ContactForm = () => {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');

    const handleSubmit = async () => {
        console.log(name + " " + phone + " " + email);
        try {
            const response = await axios.post('http://localhost:3000/contacts', { name: name, phone: phone, email: email });
            //console.log("Data sent:", response.data);
            Alert.alert('Success', 'Contact added!');
            setName('');
            setPhone('');
            setEmail('');
        } catch (error) {
            //Alert.alert('Error', error.response.data.error);
            Alert.alert('Error', error);
        }
    };

    return (
        <>
          <h1>Cadastrar contato</h1>
          <View>
            <TextInput placeholder="Name" value={name} onChangeText={setName} />
            <TextInput placeholder="Phone (14 digits)" value={phone} onChangeText={setPhone} keyboardType="numeric" maxLength={14} />
            <TextInput placeholder="Email" value={email} onChangeText={setEmail} keyboardType="email-address" />
            <Button title="Add Contact" onPress={handleSubmit} />
          </View>
        </>
    );
};

export default ContactForm;
