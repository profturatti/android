Como executar este programa no seu computador?

[!] NOTA: o símbolo $ significa o prompt do terminal/console
          Você pode utilizar o CMD, PowerShell ou equivalente

# Crie um novo aplicativo com expo

1. $ npx create-expo-app --template
     ✔ Choose a template: › Navigation (TypeScript)
     ✔ What is your app named? produtos

2. $ cd produtos

3. $ npx expo install expo-sqlite

4. $ code .

5. Apagar as pastas:
- "app", 
- "components"
- "constants"
- "fonts" (que está dentro de "assets")

6. Apague o arquivo:
- "tsconfig.json"

7. Descompacte este arquivo e copie tudo para a pasta "produtos"

8. Execute dentro de um terminal no VSCode (Terminal > New Terminal)
   $ npx expo start

9. Capture o QRCode exibido com seu celular utilizando o app "ExpoGo"

Pronto!
